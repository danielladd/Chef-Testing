default['nginx']['enable_rate_limiting'] = false
default['nginx']['rate_limiting_zone_name'] = 'default'
default['nginx']['rate_limiting_backoff'] = '10m'
default['nginx']['rate_limit'] = '1r/s'
