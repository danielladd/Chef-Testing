# github-cookbook

A Library Cookbook for interating with Github

# Author

Author:: Jamie Winsor (<jamie@vialstudios.com>)
